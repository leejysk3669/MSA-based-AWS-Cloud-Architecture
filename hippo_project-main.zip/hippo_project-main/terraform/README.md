# Terraform 인프라 관리 가이드

## 📁 폴더 구조

```
terraform/
├── stages/                    # 개발/스테이징 환경
│   ├── 01-network/           # VPC, 서브넷, 라우팅
│   ├── 02-security/          # 보안 그룹, IAM
│   ├── 03-eks/               # EKS 클러스터
│   ├── 04-rds/               # RDS 데이터베이스
│   ├── 05-frontend/          # S3, CloudFront
│   └── 06-api-gateway/       # API Gateway
├── production/                # 프로덕션 환경
└── README.md                  # 이 파일
```

## 🚀 사용법

### **개발/스테이징 환경 배포**

각 단계별로 순차적으로 실행합니다:

```bash
# 1단계: 네트워크 인프라 생성
cd terraform/stages/01-network/
terraform init
terraform plan
terraform apply

# 2단계: 보안 설정
cd ../02-security/
terraform init
terraform plan
terraform apply

# 3단계: EKS 클러스터 생성
cd ../03-eks/
terraform init
terraform plan
terraform apply

# 4단계: RDS 데이터베이스 생성
cd ../04-rds/
terraform init
terraform plan
terraform apply

# 5단계: 프론트엔드 인프라 생성
cd ../05-frontend/
terraform init
terraform plan
terraform apply

# 6단계: API Gateway 생성
cd ../06-api-gateway/
terraform init
terraform plan
terraform apply
```

### **프로덕션 환경 배포**

```bash
cd terraform/production/
terraform init
terraform plan
terraform apply
```

## 🔧 각 단계별 상세 설명

### **01-network/**
- **VPC**: 10.0.0.0/16 CIDR 블록
- **퍼블릭 서브넷**: ap-northeast-2a, ap-northeast-2c
- **프라이빗 서브넷**: NAT Gateway를 통한 인터넷 접근
- **라우팅 테이블**: 퍼블릭/프라이빗 서브넷 라우팅

### **02-security/**
- **보안 그룹**: EKS, RDS, ALB용 보안 그룹
- **IAM 역할**: EKS 클러스터, 노드 그룹용 IAM 역할
- **OIDC 공급자**: EKS 클러스터용 OIDC 설정

### **03-eks/**
- **EKS 클러스터**: Kubernetes 1.28 버전
- **노드 그룹**: t3.medium 인스턴스, 1-3개 노드
- **클러스터 자동 스케일러**: 노드 수 자동 조정

### **04-rds/**
- **PostgreSQL**: 13.12 버전
- **인스턴스 타입**: db.t3.micro
- **스토리지**: 20GB (최대 100GB 자동 확장)
- **백업**: 7일 보관

### **05-frontend/**
- **S3 버킷**: 정적 웹사이트 호스팅
- **CloudFront**: CDN 및 HTTPS 종료
- **도메인**: 커스텀 도메인 지원 (선택사항)

### **06-api-gateway/**
- **REST API**: 백엔드 서비스 연동
- **CORS**: 프론트엔드 도메인 허용
- **프록시**: ALB로의 요청 전달

## ⚠️ 주의사항

### **순서 중요**
1. **네트워크** → **보안** → **EKS** → **RDS** → **프론트엔드** → **API Gateway**
2. 각 단계는 이전 단계의 출력값에 의존합니다
3. 순서를 바꾸면 오류가 발생할 수 있습니다

### **환경 변수**
- 각 단계별로 `terraform.tfvars` 파일에서 환경별 설정 가능
- `environment` 변수로 dev/staging/prod 구분

### **상태 파일**
- 각 단계별로 독립적인 상태 파일 관리
- `terraform.tfstate` 파일 백업 권장

## 🔍 문제 해결

### **일반적인 오류**
- **리소스 의존성 오류**: 이전 단계가 완료되었는지 확인
- **권한 오류**: AWS IAM 권한 확인
- **네트워크 오류**: VPC 및 서브넷 설정 확인

### **디버깅 명령어**
```bash
# 상태 확인
terraform show

# 계획 재생성
terraform plan -refresh=true

# 특정 리소스만 재생성
terraform taint aws_instance.example
```

## 📞 지원

문제가 발생하면 다음을 확인하세요:
1. AWS 콘솔에서 리소스 상태 확인
2. Terraform 로그 및 오류 메시지 확인
3. 각 단계별 출력값 확인

---

**마지막 업데이트**: 2024년 12월
**버전**: 1.0
**환경**: AWS EKS, RDS, S3, CloudFront, API Gateway
