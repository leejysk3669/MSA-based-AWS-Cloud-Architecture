# 백엔드 CI/CD Secrets 설정 가이드

백엔드 CI/CD를 위해 추가로 필요한 Secrets를 설정해야 합니다.

## 🔐 추가 필요한 Secrets

### 1. Docker Hub 인증 정보
```
DOCKER_USERNAME: Docker Hub 사용자명
DOCKER_PASSWORD: Docker Hub 액세스 토큰 (비밀번호 아님)
```

### 2. Kubernetes 설정
```
KUBE_CONFIG: Kubernetes 설정 파일 (base64 인코딩)
``

## 📋 설정 방법

### 1. Docker Hub 액세스 토큰 생성
1. **Docker Hub** → **Account Settings** → **Security**
2. **New Access Token** 클릭
3. **Token description**: `GitHub Actions CI/CD`
4. **Access permissions**: `Read, Write, Delete`
5. **생성된 토큰을 복사** (한 번만 표시됨!)

### 2. Kubernetes 설정 파일 생성
```bash
# 현재 kubectl 설정을 base64로 인코딩
kubectl config view --raw | base64 -w 0
```

### 3. GitHub Secrets 추가
GitHub 리포지토리 → **Settings** → **Secrets and variables** → **Actions**

| Secret Name | Value | 설명 |
|-------------|-------|------|
| `DOCKER_USERNAME` | `your-dockerhub-username` | Docker Hub 사용자명 |
| `DOCKER_PASSWORD` | `dckr_pat_...` | Docker Hub 액세스 토큰 |
| `KUBE_CONFIG` | `base64-encoded-config` | Kubernetes 설정 파일 |

## 🚀 백엔드 CI/CD 특징

### **스마트 배포**
- **변경 감지**: 수정된 서비스만 자동 배포
- **병렬 처리**: 여러 서비스 동시 배포 가능
- **수동 선택**: 특정 서비스만 배포 가능

### **배포 과정**
1. **변경 감지**: `dorny/paths-filter`로 수정된 서비스 식별
2. **Docker 빌드**: 변경된 서비스의 Docker 이미지 빌드
3. **Docker Hub 푸시**: 새 이미지를 Docker Hub에 업로드
4. **Kubernetes 배포**: EKS 클러스터에서 이미지 업데이트
5. **Pod 재시작**: 새로운 이미지로 Pod 재시작

### **지원 서비스**
- ✅ **Community Board API** (`community-board-api-unified`)
- ✅ **AI Portfolio API** (`ai-portfolio`)
- ✅ **Certificate Search API** (`certificate-search`)
- ✅ **Jobs News API** (`jobs-news-api`)
- ✅ **Notification API** (`notification-api`)
- ✅ **Study Group API** (`study-group-api`)

## 🧪 테스트 방법

### **자동 실행**
```bash
# 특정 백엔드 서비스 수정 후 푸시
git add backend/community-board-api-unified/src/index.ts
git commit -m "Update community board API"
git push origin main
```

### **수동 실행**
1. **GitHub Actions** → **Backend Deploy to Kubernetes**
2. **Run workflow** 클릭
3. **service** 입력란에 배포할 서비스명 입력 (선택사항)
4. **Run workflow** 실행

### **서비스별 수동 배포**
- `community-board`: 커뮤니티 게시판 API만 배포
- `ai-portfolio`: AI 포트폴리오 API만 배포
- `certificate-search`: 자격증 검색 API만 배포
- `jobs-news`: 취업 뉴스 API만 배포
- `notification`: 알림 API만 배포
- `study-group`: 스터디 그룹 API만 배포
- (빈 값): 변경된 모든 서비스 배포

## ⚠️ 주의사항

### **Docker Hub 토큰**
- **비밀번호 사용 금지**: Docker Hub 비밀번호 대신 액세스 토큰 사용
- **토큰 권한**: Read, Write, Delete 권한 필요
- **토큰 보안**: 토큰은 안전하게 보관

### **Kubernetes 설정**
- **권한 확인**: EKS 클러스터에 대한 배포 권한 필요
- **네임스페이스**: `hippo-project` 네임스페이스 사용
- **배포 이름**: 각 서비스의 deployment 이름과 일치해야 함

## 🔍 문제 해결

### **Docker 빌드 실패**
```bash
# 로컬에서 Docker 빌드 테스트
cd backend/community-board-api-unified
docker build -t test-image .
```

### **Kubernetes 배포 실패**
```bash
# kubectl 설정 확인
kubectl config current-context
kubectl get deployments -n hippo-project
```

### **Pod 재시작 실패**
```bash
# Pod 상태 확인
kubectl get pods -n hippo-project
kubectl describe pod <pod-name> -n hippo-project
```
