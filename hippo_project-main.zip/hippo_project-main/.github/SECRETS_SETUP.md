# GitHub Secrets 설정 가이드

GitHub Actions에서 AWS 리소스에 접근하기 위해 필요한 Secrets를 설정해야 합니다.

## 🔐 필요한 Secrets

### 1. AWS 인증 정보
```
AWS_ACCESS_KEY_ID: AWS 액세스 키 ID
AWS_SECRET_ACCESS_KEY: AWS 시크릿 액세스 키
```

### 2. S3 및 CloudFront 정보
```
S3_BUCKET_NAME: S3 버킷 이름 (예: hippo-frontend-bucket)
CLOUDFRONT_DISTRIBUTION_ID: CloudFront 배포 ID (예: E1234567890ABC)
CLOUDFRONT_DOMAIN: CloudFront 도메인 (예: d1234567890abc.cloudfront.net)
```

## 📋 설정 방법

### 1. GitHub 리포지토리에서 Secrets 설정
1. GitHub 리포지토리 → **Settings** → **Secrets and variables** → **Actions**
2. **New repository secret** 클릭
3. 각 Secret을 추가:

| Secret Name | Value | 설명 |
|-------------|-------|------|
| `AWS_ACCESS_KEY_ID` | `AKIA...` | AWS 액세스 키 ID |
| `AWS_SECRET_ACCESS_KEY` | `wJalr...` | AWS 시크릿 액세스 키 |
| `S3_BUCKET_NAME` | `hippo-frontend-bucket` | S3 버킷 이름 |
| `CLOUDFRONT_DISTRIBUTION_ID` | `E1234567890ABC` | CloudFront 배포 ID |
| `CLOUDFRONT_DOMAIN` | `d1234567890abc.cloudfront.net` | CloudFront 도메인 |

### 2. AWS IAM 사용자 생성 (권장)
```bash
# AWS CLI로 IAM 사용자 생성
aws iam create-user --user-name github-actions-deploy

# 정책 생성
aws iam create-policy --policy-name GitHubActionsDeployPolicy --policy-document '{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::YOUR_BUCKET_NAME",
        "arn:aws:s3:::YOUR_BUCKET_NAME/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "cloudfront:CreateInvalidation"
      ],
      "Resource": "*"
    }
  ]
}'

# 정책 연결
aws iam attach-user-policy --user-name github-actions-deploy --policy-arn arn:aws:iam::YOUR_ACCOUNT_ID:policy/GitHubActionsDeployPolicy

# 액세스 키 생성
aws iam create-access-key --user-name github-actions-deploy
```

## 🔍 현재 AWS 리소스 확인

### S3 버킷 이름 확인
```bash
aws s3 ls | grep frontend
```

### CloudFront 배포 ID 확인
```bash
aws cloudfront list-distributions --query "DistributionList.Items[?Comment=='hippo-frontend'].{Id:Id,DomainName:DomainName}"
```

## ⚠️ 보안 주의사항

1. **최소 권한 원칙**: 필요한 권한만 부여
2. **정기적 로테이션**: 액세스 키 정기적 변경
3. **환경 분리**: 개발/운영 환경별 다른 키 사용

## 🧪 테스트

Secrets 설정 후 다음 방법으로 테스트:

1. **수동 실행**: GitHub Actions → Frontend Deploy → Run workflow
2. **코드 푸시**: frontend 폴더의 파일 수정 후 푸시
3. **로그 확인**: Actions 탭에서 실행 로그 확인
